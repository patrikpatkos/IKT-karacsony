const countdown = () => {
    const christmasDate = new Date("December 25, 2024 00:00:00").getTime();
    const now = new Date().getTime();
    const diff = christmasDate - now;
  
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);
  
    document.getElementById("days").textContent = days;
    document.getElementById("hours").textContent = hours;
    document.getElementById("minutes").textContent = minutes;
    document.getElementById("seconds").textContent = seconds;
  
    if (diff < 0) {
      clearInterval(interval);
      document.getElementById("countdown").innerHTML = "<h3>Boldog Karácsonyt!</h3>";
    }
  };
  
  const interval = setInterval(countdown, 1000);
  countdown(); 
  